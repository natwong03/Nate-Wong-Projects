Minesweeper Project:
Nate Wong
natwong@chapman.edu
CPSC 236-02
Assignment 2
This is my own work, and I did not cheat on this assignment.

Files:
  a. GridBuilder.cs
  b. GridText.cs
  c. PlayGrid.cs
  d. Tile.cs

Instructions:
  a. Load unzipped folder into Unity version 2019.4.9f1
  b. Click play button at the top of the window
  c. Click on any tile to start the game. A number will populate the tile to show how many surrounding
     mines there are. If you click a mine, an asterisk will populate the tile and the game is lost.
  d. Clear all of the mines to win the game.
