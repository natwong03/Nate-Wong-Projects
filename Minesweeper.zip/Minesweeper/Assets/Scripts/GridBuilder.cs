﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridBuilder : MonoBehaviour
{
    public GameObject GridTile;

    // Start is called before the first frame update
    void Start()
    {
        SetupGrid();
    }

    private void SetupGrid()
    {
        //What is the size of our grid?
        int gridSize = PlayGrid.Height * PlayGrid.Width;
        //Make grid tiles
        for(int tileCount = 0; tileCount < gridSize; tileCount++)
        {
            MakeTile(tileCount);
        }
    }

    private void MakeTile(int tileCount)
    {
        GameObject newGameObject = Instantiate(GridTile, gameObject.transform);
        RegisterTileToGrid(tileCount, newGameObject);
    }

    private void RegisterTileToGrid(int tileCount, GameObject newGameObject)
    {
        //Get x/y position
        int x = tileCount / PlayGrid.Width;
        int y = tileCount % PlayGrid.Width;

        //Get the tile
        Tile newTile = newGameObject.GetComponent<Tile>();

        //Assign the tile's position
        newTile.AssignGridPosition(x, y);
    }
}
