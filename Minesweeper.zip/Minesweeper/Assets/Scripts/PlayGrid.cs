﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayGrid
{
    public static int Width = 15;
    public static int Height = 15;
    public static Tile[,] tiles = new Tile[Width, Height];

    public static void ShowAllMines()
    {
        foreach(Tile tile in tiles)
        {
            if (tile.IsMine)
            {
                tile.DrawMine();
            }
        }
    }

    public static bool IsMineAtLocation(int x, int y)
    {
        if(x >= 0 && y >= 0 && x < Width && y < Height)
        {
            return tiles[x, y].IsMine;
        }
        return false;
    }

    public static int CountAdjacementMines(int x, int y)
    {
        int count = 0;

        if (IsMineAtLocation(x, y + 1)) count++;
        if (IsMineAtLocation(x + 1, y + 1)) count++;
        if (IsMineAtLocation(x + 1, y)) count++;
        if (IsMineAtLocation(x + 1, y - 1)) count++;
        if (IsMineAtLocation(x, y - 1)) count++;
        if (IsMineAtLocation(x - 1, y - 1)) count++;
        if (IsMineAtLocation(x - 1, y)) count++;
        if (IsMineAtLocation(x - 1, y + 1)) count++;

        return count;
    }

    public static void FloodFillUncover(int x, int y, bool[,] visited)
    {
        if(x >= 0 && y >= 0 && x < Width && y < Height)
        {
            //Did we already visit this space?
            if (visited[x, y])
            {
                return;
            }

            tiles[x, y].DrawMineCount();

            if(CountAdjacementMines(x, y) > 0)
            {
                return;
            }

            visited[x, y] = true;

            //Recursion
            FloodFillUncover(x - 1, y, visited);
            FloodFillUncover(x + 1, y, visited);
            FloodFillUncover(x, y - 1, visited);
            FloodFillUncover(x, y + 1, visited);
        }
    }

    public static bool IsGridClear()
    {
        foreach(Tile tile in tiles)
        {
            if(!tile.IsClear() && !tile.IsMine)
            {
                return false;
            }
        }
        return true;
    }
}
