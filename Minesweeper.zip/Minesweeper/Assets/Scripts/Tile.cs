﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Tile : MonoBehaviour
{
    public bool IsMine = false;
    public Text DisplayText;
    public Sprite Clicked;
    public Sprite Unclicked;
    public GridText GridText;

    private float mineProbability = 0.15f;
    private int x;
    private int y;

    // Start is called before the first frame update
    void Start()
    {
        IsMine = Random.value < mineProbability;
        GridText = GetComponentInParent<GridText>();
    }

    public void OnButtonClick()
    {
        if (IsMine)
        {
            //We lose
            PlayGrid.ShowAllMines();
            GridText.UpdateResultText("You lose");
        }
        else
        {
            //Draw mine count
            DrawMineCount();

            //Flood fill
            PlayGrid.FloodFillUncover(x, y, new bool[PlayGrid.Width, PlayGrid.Height]);

            //Did the player win?
           if (PlayGrid.IsGridClear() == true)
            {
                GridText.UpdateResultText("You win!");
            }
        }
    }

    public void DrawMineCount()
    {
        int count = PlayGrid.CountAdjacementMines(x, y);
        if(count > 0)
        {
            string countText = count.ToString();
            DisplayText.text = countText;
        }
        //Set clicked sprite to be used
        GetComponent<Image>().sprite = Clicked;
        GetComponent<Button>().interactable = false;
    }

    public void AssignGridPosition(int xPosition, int yPosition)
    {
        x = xPosition;
        y = yPosition;
        PlayGrid.tiles[x, y] = this;
        gameObject.name = x + "," + y; //makes position more readable for us
    }

    public void DrawMine()
    {
        DisplayText.text = "*";
    }

    public bool IsClear()
    {
        Sprite currentSprite = GetComponent<Image>().sprite;
        if(currentSprite == Clicked)
        {
            return true;
        }
        return false;
    }
}
