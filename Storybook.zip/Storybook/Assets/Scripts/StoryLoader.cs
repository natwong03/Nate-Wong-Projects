﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;
using System.IO; //for streamreader and streamwriter

public static class StoryLoader
{
    private static string folderName = "Assets/Stories";

    //retrieves files from the identified folder
    private static string[] storyFileNames()
    {
        return Directory.GetFiles(folderName);
    }

    //creates a list of lists which each hold the respective strings for each story
    public static List<List<string>> LoadAllStories()
    {
        List<List<string>> stories = new List<List<string>>();

        foreach(string file in storyFileNames())
        {
            if (!file.Contains(".meta"))
            {
                List<string> story = LoadStory(file);
                stories.Add(story);
            }
        }
        return stories;
    }

    //reads data within the given file path and writes it to a list which will later
    //be read from and broken down to individual parts of the story
    private static List<string> LoadStory(string filePath)
    {
        List<string> storyText = new List<string>();

        StreamReader reader = new StreamReader(filePath);
        string storyLine = string.Empty;

        while((storyLine = reader.ReadLine()) != null)
        {
            storyText.Add(storyLine);
        }
        reader.Close();

        return storyText;
    }

}
