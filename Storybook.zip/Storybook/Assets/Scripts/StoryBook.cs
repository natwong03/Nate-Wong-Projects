﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StoryBook : Book
{
    public Text BookTitle;
    public Text Author;
    public Image CoverImage;

    public Image Page1Image;
    public Image Page2Image;
    public Image Page3Image;
    public Image Page4Image;
    public Image Page5Image;
    public Image Page6Image;
    public Image Page7Image;
    public Image Page8Image;

    //pulls up and displays the chosen story
    void Start()
    {
        AssignStory(StoriesManager.Instance.Stories[StoriesManager.Instance.SelectedIndex]);
    }

    public override void OnForwardButtonClick()
    {
        base.OnForwardButtonClick();
        if (pageCount > 0)
        {
            HideTitle();
        }
    }

    public override void OnPreviousButtonClick()
    {
        base.OnPreviousButtonClick();
        if (pageCount < 1)
        {
            ShowTitle();
        }
    }

    public void HideTitle()
    {
        BookTitle.gameObject.SetActive(false);
        Author.gameObject.SetActive(false);
        CoverImage.gameObject.SetActive(false);
    }

    public void ShowTitle()
    {
        BookTitle.gameObject.SetActive(true);
        Author.gameObject.SetActive(true);
        CoverImage.gameObject.SetActive(true);
    }

    public void AssignStory(Story story)
    {
        //Set the book title
        BookTitle.text = story.GetTitle();

        //set the author
        Author.text = story.GetAuthor();

        //set the cover image
        CoverImage.sprite = PageSprite(story.GetPageImages()[0]);

        //set all the page texts
        AssignPageText(story.GetPageTexts());

        //set all the page images
        Page1Image.sprite = PageSprite(story.GetPageImages()[0]);
        Page2Image.sprite = PageSprite(story.GetPageImages()[1]);
        Page3Image.sprite = PageSprite(story.GetPageImages()[2]);
        Page4Image.sprite = PageSprite(story.GetPageImages()[3]);
        Page5Image.sprite = PageSprite(story.GetPageImages()[4]);
        Page6Image.sprite = PageSprite(story.GetPageImages()[5]);
        Page7Image.sprite = PageSprite(story.GetPageImages()[6]);
        Page8Image.sprite = PageSprite(story.GetPageImages()[7]);

        //show book cover
        ShowTitle();
    }

    //retrieves the text to go along with each page and inserts it into the text gameobject
    public void AssignPageText(List<string> pageTexts)
    {
        for (int count = 1; count < 9; count++)
        {
            Pages[count].GetComponentInChildren<Text>().text = pageTexts[count - 1];
        }
    }

    //retrieves the picture the author chose and inserts it as the sprite for that page
    private Sprite PageSprite(string fileName)
    {
        Sprite newSprite;
        newSprite = Resources.Load<Sprite>("Images/" + fileName);
        return newSprite;
    }
}
