﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;
using UnityEngine.UI;

public class ButtonInfo : MonoBehaviour
{
    private Story story;

    private Text buttonText;
    private Image buttonImage;

    public int StoryIndex;

    void Start()
    {
        buttonText = GetComponentInChildren<Text>();
        buttonImage = GetComponentInChildren<Image>();

        SetButtonTextByStoryIndex();
        SetButtonImageByStoryIndex();
    }

    //gets the story's title and displays it under the button
    private void SetButtonTextByStoryIndex()
    {
        string title = StoriesManager.Instance.Stories[StoryIndex].GetTitle();
        buttonText.text = title;
    }

    //gets the cover image to display as the button's image
    private void SetButtonImageByStoryIndex()
    {
        string spriteFileName = StoriesManager.Instance.Stories[StoryIndex].GetPageImages()[0];

        Sprite coverSprite;
        coverSprite = Resources.Load<Sprite>("Images/" + spriteFileName);

        buttonImage.sprite = coverSprite;
    }
}
