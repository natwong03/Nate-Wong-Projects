﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;

public class Book : MonoBehaviour
{
    public int pageCount = 0;

    public CanvasGroup[] Pages;
    public CanvasGroup ForwardButton;
    public CanvasGroup PreviousButton;

    void Start()
    {
        HidePreviousButton();
    }

    //has a counter to limit itself from turning to a page that doesn't exist
    public virtual void OnForwardButtonClick()
    {
        if (pageCount < Pages.Length - 1)
        {
            TurnOffPage();
            pageCount++;
            DisplayForwardButton();
            DisplayPreviousButton();
            TurnOnPage();
        }
    }

    private void DisplayForwardButton()
    {
        if (pageCount == Pages.Length - 1)
        {
            HideForwardButton();
        }

        else
        {
            ShowForwardButton();
        }
    }

    private void HideForwardButton()
    {
        ForwardButton.alpha = 0;
        ForwardButton.interactable = false;
    }

    private void ShowForwardButton()
    {
        ForwardButton.alpha = 1;
        ForwardButton.interactable = true;
    }

    //has a counter to limit itself from turning to a page that doesn't exist
    public virtual void OnPreviousButtonClick()
    {
        if (pageCount > 0)
        {
            TurnOffPage();
            pageCount--;
            DisplayForwardButton();
            DisplayPreviousButton();
            TurnOnPage();
        }
    }

    private void DisplayPreviousButton()
    {
        if (pageCount == 0)
        {
            HidePreviousButton();
        }
        else
        {
            ShowPreviousButton();
        }
    }

    private void HidePreviousButton()
    {
        PreviousButton.alpha = 0;
        PreviousButton.interactable = false;
    }

    private void ShowPreviousButton()
    {
        PreviousButton.alpha = 1;
        PreviousButton.interactable = true;
    }

    void TurnOffPage()
    {
        Pages[pageCount].alpha = 0;
        Pages[pageCount].gameObject.SetActive(false);
    }

    void TurnOnPage()
    {
        Pages[pageCount].alpha = 1;
        Pages[pageCount].gameObject.SetActive(true);
    }
}
