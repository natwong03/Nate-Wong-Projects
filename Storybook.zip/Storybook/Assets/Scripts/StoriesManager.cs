﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;
using UnityEngine;

//Awake() method was from the provided storybook example from Prof. Prate

public class StoriesManager : MonoBehaviour
{
    public static StoriesManager Instance;
    public List<Story> Stories = new List<Story>();
    public int SelectedIndex = 0; //stores the selected index across scenes

    private void Awake()
    {
        if(Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(this);
        }
        else
        {
            Destroy(this);
        }
    }

    void Start()
    {
        PopulateStories();
    }

    //loads and adds all provided stories to a list which they will later be indexed from
    private void PopulateStories()
    {
        List<List<string>> loadedStories = StoryLoader.LoadAllStories();

        foreach(List<string> story in loadedStories)
        {
            Story newStory = new Story(story);
            Stories.Add(newStory);
        }
    }
}
