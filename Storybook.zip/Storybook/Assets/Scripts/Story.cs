﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;

public class Story
{
    private string title;
    private string author;
    private List<string> pageTexts = new List<string>();
    private List<string> pageImages = new List<string>();

    //takes strings from the passed list and stores the author, title, page text, and page images
    public Story(List<string> storyData)
    {
        title = storyData[0];
        author = storyData[1];

        for(int count = 2; count < 10; count++)
        {
            pageTexts.Add(storyData[count]);
        }

        for(int count = 10; count < 18; count++)
        {
            pageImages.Add(storyData[count]);
        }
    }

    public string GetAuthor()
    {
        return author;
    }

    public string GetTitle()
    {
        return title;
    }

    public List<string> GetPageTexts()
    {
        return pageTexts;
    }

    public List<string> GetPageImages()
    {
        return pageImages;
    }
}
