﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;
using UnityEngine;

public class ChooseAStory : MonoBehaviour
{
    private System.Random random = new System.Random();

    //brings up the chosen story based on its index
    public void OnClickSetStoryIndex(int index)
    {
        StoriesManager.Instance.SelectedIndex = index;
    }

    //chooses a random story for the storytime! function
    public void OnClickSetRandomStoryIndex()
    {
        List<List<string>> loadedStories = StoryLoader.LoadAllStories();

        StoriesManager.Instance.SelectedIndex = random.Next(loadedStories.Count);
    }
}
