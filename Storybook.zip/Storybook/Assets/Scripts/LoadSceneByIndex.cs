﻿/*
Nate Wong
ID# 2344037
natwong@chapman.edu
CPSC 236-02
Assignment 4, Storybook
This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;
using UnityEngine.SceneManagement; //allows us to load different scenes within the project
using UnityEditor;

public class LoadSceneByIndex : MonoBehaviour
{
    public void OnClickLoadScene(int sceneIndex)
    {
        SceneManager.LoadScene(sceneIndex);
    }

    //checks if the unity editor is being used to run the program and ends the program if it is,
    //if it's being used in a standalone app it quits the app
    public void QuitApplication()
    {
        if (EditorApplication.isPlaying)
        {
            EditorApplication.isPlaying = false;
        }
        else
        {
            Application.Quit();
        }
    }
}
