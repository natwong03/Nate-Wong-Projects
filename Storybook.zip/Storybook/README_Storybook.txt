1) Identifying Information
  a. Nate Wong
  b. ID# 2344037
  c. natwong@chapman.edu
  d. CPSC 236-02
  e. Assignment 4, Storybook
  f. This is my own work, and I did not cheat on this assignment.

2) List of source files submitted
  a. Book.cs
  b. ButtonInfo.cs
  c. ChooseAStory.cs
  d. LoadSceneByIndex.cs
  e. StoriesManager.cs
  f. Story.cs
  g. StoryBook.cs
  h. StoryLoader.cs

3) Description of any known compile/runtime errors, or bugs
  a. I wasn't able to create Choose A Story pages and buttons dynamically to
     account for more or less stories than those from the original class stories folder.
     Tried using page prefabs and button prefabs but had a lot of trouble getting them
     to cooperate and function correctly

4) References used to complete the assignment
  a. Storybook example from Prof. Prate
  b. https://docs.unity3d.com/ScriptReference/EditorApplication.Exit.html
  c. https://docs.unity3d.com/ScriptReference/EditorApplication-isPlaying.html

5) Instructions for running the assignment
  a. Unzip compressed file called Storybook
  b. Load unzipped folder into Unity version 2019.4.9f1
  c. Click play button at the top of the window
  d. Choosing the Storytime! feature by clicking the button, will load a random
     story from the class' stories
  e. Click the forward or previous page buttons to navigate through the book
  f. When available, you may click the "Back" button to return to the main menu
  g. Choosing the Choose A Story feature by clicking the button, will show a gallery
     of the class' stories to choose from, click the forward or previous page buttons
     to navigate through the pages of available stories
  h. If the user wishes to quit the application, they can return to the main menu
     and click the quit button, this will quit the application if the program is running
     as a standalone application, and will end the play mode if the program is being
     used within the Unity Editor
