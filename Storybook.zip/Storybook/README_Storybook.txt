Storybook Project:
Nate Wong
natwong@chapman.edu
CPSC 236-02
Assignment 4
This is my own work, and I did not cheat on this assignment.

Files:
  a. Book.cs
  b. ButtonInfo.cs
  c. ChooseAStory.cs
  d. LoadSceneByIndex.cs
  e. StoriesManager.cs
  f. Story.cs
  g. StoryBook.cs
  h. StoryLoader.cs

Instructions:
  a. Unzip compressed file called Storybook
  b. Load unzipped folder into Unity version 2019.4.9f1
  c. Click play button at the top of the window
  d. Choosing the Storytime! feature by clicking the button, will load a random
     story from the class' stories
  e. Click the forward or previous page buttons to navigate through the book
  f. When available, you may click the "Back" button to return to the main menu
  g. Choosing the Choose A Story feature by clicking the button, will show a gallery
     of the class' stories to choose from, click the forward or previous page buttons
     to navigate through the pages of available stories
  h. If the user wishes to quit the application, they can return to the main menu
     and click the quit button, this will quit the application if the program is running
     as a standalone application, and will end the play mode if the program is being
     used within the Unity Editor
