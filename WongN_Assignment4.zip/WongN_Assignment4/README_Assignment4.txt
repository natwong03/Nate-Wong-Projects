Nate Wong
Chapman University Student

This assignment's objective was to read the contents of a .txt file, in this case
the entire first chapter of Harry Potter and the Sorcerer's Stone, and count how
many times a word is repeated. Essentially, building a basic natural language processor.
The words and their respective counts are then written to another .txt file in descending
order.

To use the python script, you can load the file into Terminal or Power Shell and the program
will run.
