# Nate Wong
# 2344037
# natwong@chapman.edu
# CPSC 230-01
# Assignment 4

import operator #imports operator module to later sort the dictionary

def read_file(file1): #this defines the read_file funciton to read the data in the input file that the user wants to filter words from
    input_file = open(file1, 'r') #possible error
    text = input_file.read().lower() #reads the data in the user's file and makes the string lowercase to account for case later
    input_file.close() #closes the user's file
    return text

def build_dictionary(file_string):
    string_list = file_string.split() #splits up each word by spaces so they can be properly counted
    stripped_list = [] #makes a new list for cleaned up strings
    for string in string_list: #iterates over each string in the list so unwanted punctuation can be removed
        strip_this = '!?,".-;:' #identifies unwanted punctuation
        text_stripped = string.strip(strip_this) #removes the identified punctuation
        stripped_list.append(text_stripped) #adds cleaned strings to the new list
    string_dict = {} #establishes the dictionary that will hold the words and their respective counts
    for string in stripped_list: #lets us iterate over each word in the file
        if string in string_dict: #checks for membership in the dictionary and adds to the word's count
            string_dict[string] += 1 #adds a value of 1 to an existing key
        elif string == '': #checks for any random spaces that survived, had an odd occurence of 52 '' showing up in results so this took care of it nicely, we want to count words after all not blank spaces
            continue #skips the iteration and goes on to the next one
        else: #if not in the dictionary yet it gives a starting value of 1
            string_dict[string] = 1 #creates a new key and value
    sorted_list = sorted(string_dict.items(), key=operator.itemgetter(1)) #sorts the finished dictionary in ascending value
    sorted_list.reverse() #puts the list in order of most repeated to least repeated
    final_dict = {} #establishes our final dictionary
    for tuple in sorted_list: #iterates over each tuple in the list and adds it to the master dicitonary
        final_dict[tuple[0]] = tuple[1] #maps the tuple indexes to the dictionary
    return final_dict

def write_file(output_dict, file2):
    output_file = open(file2, 'w') #opens new output file for writing
    for word, count in output_dict.items(): #iterates over the final dictionary with both the key and value
        output_file.write(str(word) + ' ' + str(count) + '\n') #writes the word and its respective count to the output file
    output_file.close() #closes output file
    message = print("\nDone! Check counts.txt for the results.")
    return message

#main
loop = 1
while loop != 0: #added a loop so the program reprompts the user for a valid file until a valid file is found
    source_file = input('Enter the name of your file: ')
    try: #the following contains a possible error
        source_string = read_file(source_file) #executes the read_file function with the user's file name they input
        word_count_dict = build_dictionary(source_string) #executes the build_dictionary funciton using the string that read and stored from the input file
        write_file(word_count_dict, 'counts.txt') #executes the write_file function taking the previously built dictionary and writing it to the output file
        loop = 0
    except FileNotFoundError: #the possible resulting error if the user's input doesn't match the file name
        print(source_file, "wasn't found.") #displays this if there is an error
