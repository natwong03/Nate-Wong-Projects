Panthers vs. Paws Project:
Nate Wong
natwong@chapman.edu
CPSC 236-02
Assignment 3
This is my own work, and I did not cheat on this assignment.

Files:
  a. AI.cs
  b. BoardSpace.cs
  c. DifficultyButton.cs
  d. DifficultyPage.cs
  e. GameBackground.cs
  f. GameHandler.cs
  g. PlayerTypeButton.cs
  h. StartPage.cs

Description of any known compile/runtime errors, or bugs:
  a. The AI Difficulty selection panel won't hide properly for some reason, we couldn't figure
     it out in office hours, so a "cover panel" was used to hide the buttons during gameplay.
     The difficulty buttons are not interactable during the main gameplay, so functionality
     isn't broken.

Instructions:
  a. Load unzipped folder into Unity version 2019.4.9f1
  b. Click play button at the top of the window
  c. Choose to play against another human or to play against the AI
  d. If you chose to play the AI, choose an easy or hard difficulty. Easy AI
     will randomly pick an empty tile, Hard AI will try to fill in 3 tiles in a
     row in a non-random fashion
  e. Click on a tile to set your first move, the turn will then change to Player 2
  f. Continue until a player has won or it is a tie, to play again, click the restart button
