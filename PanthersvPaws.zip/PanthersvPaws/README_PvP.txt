1) Identifying Information
  a. Partner #1: Nate Wong
  b. ID# 2344037
  c. natwong@chapman.edu
  d. Partner #2: Grant Ward
  e. ID# 2355746
  f. gward@chapman.edu
  g. CPSC 236-02
  h. Midterm Assignment, Panthers vs. Paws
  i. This is my own work, and I did not cheat on this assignment.

2) List of source files submitted
  a. AI.cs
  b. BoardSpace.cs
  c. DifficultyButton.cs
  d. DifficultyPage.cs
  e. GameBackground.cs
  f. GameHandler.cs
  g. PlayerTypeButton.cs
  h. StartPage.cs

3) Description of any known compile/runtime errors, or bugs
  a. The AI Difficulty selection panel won't hide properly for some reason, we couldn't figure
     it out in office hours, so a "cover panel" was used to hide the buttons during gameplay.
     The difficulty buttons are not interactable during the main gameplay, so functionality
     isn't broken.

4) References used to complete the assignment
  a. Class projects (Minesweeper and Keypad)
  b. https://docs.microsoft.com/en-us/dotnet/api/system.collections.generic?view=net-5.0

5) Instructions for running the assignment
  a. Unzip compressed file called PanthersvPaws
  b. Load unzipped folder into Unity version 2019.4.9f1
  c. Click play button at the top of the window
  d. Choose to play against another human or to play against the AI
  e. If you chose to play the AI, choose an easy or hard difficulty. Easy AI
     will randomly pick an empty tile, Hard AI will try to fill in 3 tiles in a
     row in a non-random fashion
  f. Click on a tile to set your first move, the turn will then change to Player 2
  g. Continue until a player has won or it is a tie, to play again, click the restart button
