﻿/* Partner 1: Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * Partner 2: Grant Ward
 * ID# 2355746
 * gward@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;

public class DifficultyButton : MonoBehaviour
{
    public string DifficultyButtonValue;
    public DifficultyPage DifficultyPage;

    public void OnClick()
    {
        DifficultyPage.RegisterButtonClick(DifficultyButtonValue);
    }
}
