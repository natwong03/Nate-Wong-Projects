﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;
using UnityEngine.UI;

public class BoardSpace : MonoBehaviour
{
    public GameHandler gameHandler;

    public Image ownerImage;
    public Sprite defaultSprite;
    public Sprite panther;
    public Sprite paw;
    
    public int playerOwner = 1;
    public int gridSpot = 0;

    public void SetOwner(int owner)
    {
        playerOwner = owner;

        if (playerOwner == 1)
        {
            GetComponent<Image>().sprite = panther;
            gameHandler.tileArray[gridSpot] = playerOwner;
        }
        if (playerOwner == 2)
        {
            GetComponent<Image>().sprite = paw;
            gameHandler.tileArray[gridSpot] = playerOwner;
        }
    }

    public void ResetOwner()
    {
        playerOwner = 0;
        ownerImage.sprite = defaultSprite;
    }
}
