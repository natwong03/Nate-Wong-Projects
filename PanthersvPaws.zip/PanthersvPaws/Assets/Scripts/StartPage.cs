﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;

public class StartPage : MonoBehaviour
{
    public GameBackground background;
    public string PlayerType;

    void Update()
    {
        CheckPlayerOption(PlayerType);
    }

    public void RegisterButtonClick(string buttonValue)
    {
        PlayerType = buttonValue;
    }

    public void CheckPlayerOption(string PlayerType)
    {
        if (PlayerType == "Human")
        {
            background.HideStartPanel();
            background.ShowGamePanel();
        }
        if (PlayerType == "AI")
        {
            background.HideStartPanel();
            background.ShowDifficultyPanel();
        }
    }

    public void ToInstructions()
    {
        background.HideStartPanel();
        background.ShowInstructionsPanel();
    }

    public void LeaveInstructions()
    {
        background.HideInstructionsPanel();
        background.ShowStartPanel();
    }
}
