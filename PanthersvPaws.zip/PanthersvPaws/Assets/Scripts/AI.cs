﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;
using UnityEngine;

public class AI : MonoBehaviour
{
    public System.Random rd = new System.Random();

    public StartPage startPage;
    public DifficultyPage difficultyPage;
    public GameHandler gameHandler;
    public BoardSpace[] boardSpaces;
    public List<int> openSpaceIndexes;
    public int[,] emptyRowArray = new int[8, 4] { {0, 0, 0, 0}, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 }, { 0, 0, 0, 0 } };

    public int indexCount = 0;
    public int randomListIndex = 9;
    public int ownerOfTile = 3;
    public int chosenTileIndex = 9;

    public bool set = false;

    void Update()
    {
        EasyAI();
        HardAI();
    }

    public void EasyAI()
    {
        if (startPage.PlayerType == "AI")
        {
            if (difficultyPage.Difficulty == "Easy")
            {
                if (gameHandler.player == 2)
                {
                    if (gameHandler.gameOver == false)
                    {
                        foreach (int value in gameHandler.tileArray)
                        {
                            ownerOfTile = value;

                            if (ownerOfTile == 0)
                            {
                                openSpaceIndexes.Add(indexCount);
                            }

                            indexCount += 1;
                        }

                        indexCount = 0;

                        randomListIndex = rd.Next(openSpaceIndexes.Count);
                        chosenTileIndex = openSpaceIndexes[randomListIndex];

                        ownerOfTile = 3;
                        randomListIndex = 9;
                        openSpaceIndexes.Clear();

                        SetOwnerAsAI(chosenTileIndex);

                        chosenTileIndex = 9;
                        gameHandler.WinCheck();

                        if (gameHandler.totalTurnCount < 8)
                        {
                            gameHandler.ChangeTurn();
                        }
                    }
                }
            }
        }
    }

    public void HardAI()
    {
        if (startPage.PlayerType == "AI")
        {
            if (difficultyPage.Difficulty == "Hard")
            {
                if (gameHandler.player == 2)
                {
                    if (gameHandler.gameOver == false)
                    {
                        if (gameHandler.totalTurnCount == 1)
                        {
                            foreach (int value in gameHandler.tileArray)
                            {
                                ownerOfTile = value;

                                if (ownerOfTile == 0)
                                {
                                    openSpaceIndexes.Add(indexCount);
                                }

                                indexCount += 1;
                            }

                            indexCount = 0;

                            randomListIndex = rd.Next(openSpaceIndexes.Count);
                            chosenTileIndex = openSpaceIndexes[randomListIndex];

                            ownerOfTile = 3;
                            randomListIndex = 9;
                            openSpaceIndexes.Clear();

                            SetOwnerAsAI(chosenTileIndex);
                        }

                        else
                        {
                            gameHandler.CheckForBestMove();
                        }

                        gameHandler.WinCheck();

                        if (gameHandler.totalTurnCount < 8)
                        {
                            gameHandler.ChangeTurn();
                        }

                        gameHandler.aiHasPlacedTile = false;
                    }
                }
            }
        }
    }

    public void SetOwnerAsAI(int index)
    {
        if (index == 0)
        {
            boardSpaces[0].SetOwner(2);
        }
        if (index == 1)
        {
            boardSpaces[1].SetOwner(2);
        }
        if (index == 2)
        {
            boardSpaces[2].SetOwner(2);
        }
        if (index == 3)
        {
            boardSpaces[3].SetOwner(2);
        }
        if (index == 4)
        {
            boardSpaces[4].SetOwner(2);
        }
        if (index == 5)
        {
            boardSpaces[5].SetOwner(2);
        }
        if (index == 6)
        {
            boardSpaces[6].SetOwner(2);
        }
        if (index == 7)
        {
            boardSpaces[7].SetOwner(2);
        }
        if (index == 8)
        {
            boardSpaces[8].SetOwner(2);
        }
    }
}
