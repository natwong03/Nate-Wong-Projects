﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;
using UnityEngine.UI;

public class GameHandler : MonoBehaviour
{
    public AI ai;
    public DifficultyPage difficultyPage;
    public GameBackground background;
    public StartPage startPage;
    
    public BoardSpace[] boardSpaces;
    public int[] tileArray = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
    
    public Text turnText = null;
    public Text winText = null;
    public GameObject turnTextObject;
    public GameObject winTextObject;
    public GameObject playAgainBtn;

    public int player = 0;
    public int totalTurnCount = 0;

    public bool gameOver = false;
    public bool aiHasPlacedTile = false;

    void Start()
    {
        StartGame();
    }

    public void StartGame()
    {
        background.ShowStartPanel();
        background.HideGamePanel();
        background.HideDifficultyPanel();
        background.HideCoverPanel();
        background.HideInstructionsPanel();
        player = 1;
        playAgainBtn.SetActive(false);
        winTextObject.SetActive(false);
        turnTextObject.SetActive(true);
        turnText.text = "Player 1's Turn";
    }

    public void RestartGame()
    {
        tileArray = new int [9];

        foreach (var i in boardSpaces)
        {
            i.ResetOwner();
        }

        winTextObject.SetActive(false);
        turnTextObject.SetActive(true);
        startPage.PlayerType = null;
        difficultyPage.Difficulty = null;
        totalTurnCount = 0;
        background.ShowStartPanel();
        background.HideGamePanel();
        
        gameOver = false;

        StartGame();
    }

    public void SetBoardSpace(BoardSpace thisSpace)
    {
        if (gameOver == false)
        {
            if (thisSpace.playerOwner == 0)
            {
                thisSpace.SetOwner(player);

                WinCheck();

                if (totalTurnCount < 8)
                {
                    ChangeTurn();
                }
            }
        }
    }

    public void ChangeTurn()
    {
        if (player == 1)
        {
            player = 2;
        }
        else
        {
            player = 1;
        }
        SetTurnText();
        totalTurnCount += 1;
    }

    public void CheckForBestMove()
    {
        if (ai.chosenTileIndex == 0)
        {
            if (tileArray[1] == 0 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[1].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[1] == 2 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[2].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[3] == 0 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[3].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[3] == 2 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[6].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 0 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[8].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 1)
        {
            if (tileArray[0] == 0 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[0].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[0] == 2 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[2].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 0 && tileArray[7] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[7] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[7].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 2)
        {
            if (tileArray[0] == 0 && tileArray[1] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[0].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[0] == 2 && tileArray[1] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[1].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[5] == 0 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[5].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[5] == 2 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[8].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 0 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[6].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 3)
        {
            if (tileArray[4] == 0 && tileArray[5] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[5] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[5].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[0] == 0 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[0].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[0] == 2 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[6].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 4)
        {
            if (tileArray[0] == 0 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[0].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[0] == 2 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[8].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[2] == 0 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[2].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[2] == 2 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[6].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[3] == 0 && tileArray[5] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[3].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[3] == 2 && tileArray[5] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[5].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[1] == 0 && tileArray[7] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[1].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[1] == 2 && tileArray[7] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[7].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 5)
        {
            if (tileArray[4] == 0 && tileArray[3] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[3] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[3].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[2] == 0 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[2].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[2] == 2 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[8].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 6)
        {
            if (tileArray[7] == 0 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[7].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[7] == 2 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[8].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[3] == 0 && tileArray[0] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[3].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[3] == 2 && tileArray[0] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[0].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 0 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[2].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 7)
        {
            if (tileArray[6] == 0 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[6].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[6] == 2 && tileArray[8] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[8].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 0 && tileArray[1] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[1] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[1].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }

        else if (ai.chosenTileIndex == 8)
        {
            if (tileArray[7] == 0 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[7].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[7] == 2 && tileArray[6] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[6].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[5] == 0 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[5].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[5] == 2 && tileArray[2] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[2].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 0 && tileArray[0] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[4].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else if (tileArray[4] == 2 && tileArray[0] == 0 && aiHasPlacedTile == false)
            {
                boardSpaces[0].SetOwner(2);
                aiHasPlacedTile = true;
            }

            else
            {
                foreach (int value in tileArray)
                {
                    ai.ownerOfTile = value;

                    if (ai.ownerOfTile == 0)
                    {
                        ai.openSpaceIndexes.Add(ai.indexCount);
                    }

                    ai.indexCount += 1;
                }

                ai.indexCount = 0;

                ai.randomListIndex = ai.rd.Next(ai.openSpaceIndexes.Count);
                ai.chosenTileIndex = ai.openSpaceIndexes[ai.randomListIndex];

                ai.ownerOfTile = 3;
                ai.randomListIndex = 9;
                ai.openSpaceIndexes.Clear();

                ai.SetOwnerAsAI(ai.chosenTileIndex);
            }
        }
    }

    public void WinCheck()
    {
        //checks horizontal patterns
        CheckPattern(0, 1, 2);
        CheckPattern(3, 4, 5);
        CheckPattern(6, 7, 8);

        //checks vertical patterns
        CheckPattern(0, 3, 6);
        CheckPattern(1, 4, 7);
        CheckPattern(2, 5, 8);

        //checks diagonal patterns
        CheckPattern(0, 4, 8);
        CheckPattern(2, 4, 6);

        if (gameOver == false && totalTurnCount == 8)
        {
            ResultTie();
        }
    }

    void CheckPattern(int space1, int space2, int space3)
    {
        if (tileArray[space1] != 0 && tileArray[space2] != 0 && tileArray[space3] != 0)
        {
            if (tileArray[space1] == tileArray[space2] && tileArray[space2] == tileArray[space3])
            {
                ResultWinner(tileArray[space1]);
            }
        }
    }

    void SetTurnText()
    {
        turnText.text = "Player " + player + "'s Turn";
    }

    void ResultWinner(int winningPlayerInt)
    {
        turnTextObject.SetActive(false);
        winTextObject.SetActive(true);
        winText.text = "Player " + winningPlayerInt + " Wins!";
        GameEnd();
    }

    void ResultTie()
    {
        turnText.text = "It's a tie!";
        GameEnd();
    }

    void GameEnd()
    {
        gameOver = true;
        playAgainBtn.SetActive(true);
    }
}
