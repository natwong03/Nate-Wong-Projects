﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;

public class DifficultyPage : MonoBehaviour
{
    public GameBackground background;
    public string Difficulty;

    void Update()
    {
        CheckDifficulty(Difficulty);
    }

    public void RegisterButtonClick(string buttonValue)
    {
        Difficulty = buttonValue;
    }

    public void CheckDifficulty(string Difficulty)
    {
        if (Difficulty == "Easy")
        {
            background.HideDifficultyPanel();
            background.ShowCoverPanel();
            background.ShowGamePanel();
        }
        if (Difficulty == "Hard")
        {
            background.HideDifficultyPanel();
            background.ShowCoverPanel();
            background.ShowGamePanel();
        }
    }
}
