﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Midterm Asignment, Panthers vs. Paws
 * This is my own work, and I did not cheat on this assignment.
*/

using UnityEngine;

public class GameBackground : MonoBehaviour
{
    public GameObject startPanel;
    public GameObject aiDifficultyPanel;
    public GameObject gameBoardPanel;
    public GameObject coverPanel; //Because the Difficulty panel won't properly deactivate for an unknown reason, this is used to conceal it, couldn't find a better solution in office hours
    public GameObject instructionsPanel;

    public void HideStartPanel()
    {
        startPanel.SetActive(false);
    }

    public void ShowStartPanel()
    {
        startPanel.SetActive(true);
    }

    public void HideDifficultyPanel()
    {
        aiDifficultyPanel.SetActive(false);
    }

    public void ShowDifficultyPanel()
    {
        aiDifficultyPanel.SetActive(true);
    }

    public void HideGamePanel()
    {
        gameBoardPanel.SetActive(false);
    }

    public void ShowGamePanel()
    {
        gameBoardPanel.SetActive(true);
    }

    public void HideCoverPanel()
    {
        coverPanel.SetActive(false);
    }

    public void ShowCoverPanel()
    {
        coverPanel.SetActive(true);
    }

    public void HideInstructionsPanel()
    {
        instructionsPanel.SetActive(false);
    }

    public void ShowInstructionsPanel()
    {
        instructionsPanel.SetActive(true);
    }
}
