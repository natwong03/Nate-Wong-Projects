1) Identifying Information
  a. Partner #1: Nate Wong
  b. ID# 2344037
  c. natwong@chapman.edu
  d. Partner #2: Grant Ward
  e. ID# 2355746
  f. gward@chapman.edu
  g. CPSC 236-02
  h. Midterm Assignment, Panthers vs. Paws
  i. This is my own work, and I did not cheat on this assignment.

  2) List of source files submitted
    a. DataSaver.cs
    b. DataLoader.cs
    c. Pyramid.cs
    d. DataManager.cs

  3) Description of any known compile/runtime errors, or bugs
    a. None

  4) References used to complete the assignment
    a. Class projects (Storybook, Data Logger)
    b. https://docs.unity3d.com/ScriptReference/MonoBehaviour.OnApplicationQuit.html
    c. https://www.youtube.com/watch?v=Z6pEAngpR9I&ab_channel=OXMONDTutorials
    d. https://stackoverflow.com/questions/6817266/how-to-get-the-current-date-without-the-time
    e. https://docs.microsoft.com/en-us/dotnet/framework/data/adonet/sql/linq/system-datetime-methods
    f. https://stackoverflow.com/questions/4989394/c-sharp-get-date-from-computer/4989414
    g. https://answers.unity.com/questions/888362/how-to-change-alpha-channel-of-ui-image.html
    h. https://www.mayoclinic.org/healthy-lifestyle/nutrition-and-healthy-eating/in-depth/dash-diet/art-20050989
    i.https://www.tutorialsteacher.com/articles/convert-string-to-int

  5) Instructions for running the assignment
    a. Unzip compressed file called FoodPyramidTracker
    b. Load unzipped folder into Unity version 2019.4.9f1
    c. Make sure the Unity Player aspect ratio is set to 4:3, and Low Resolution aspect ratios is UN-checked
    d. Click play button at the top of the window
    e. You can view what constitutes
       a serving for each of the 8 food groups by clicking the "Serving Size Example" button, click the "Back" button
       to return to the home screen
    f. Next, click on any of the 8 food groups to add or take away servings for that group
    g. Click the "Up" or the "Down" button to increase or decrease the value you want to add to the current total for that group.
       The value you will add to the group's total is reflected in the center. Click the "Confirm" button to enter that value.
       Click back to exit the servings adjustment screen if you don't want to edit that food group's total.
    h. The servings count next to the food group button on the main menu shows your total saved servings in comparison
       to what is recommended as the typical person's daily intake by the Mayo Clinic.
       https://www.mayoclinic.org/healthy-lifestyle/nutrition-and-healthy-eating/in-depth/dash-diet/art-20050989
    i. Click the pause button on the top center of the Unity Editor window to stop the program, doing so will
       automatically save the data you entered to a .txt file
    j. In order to test the daily reset functionality, open the txt file named UserData.txt, found within the Scripts folder,
       which is in the project's Assets folder. On the first line of the file, a date is written in the format of DD/MM/YYYY.
       Change any of those numbers to alter the saved date to a previous date, and put in any desired number in the following
       8 lines (this will help show a change later). This will simulate the user's data that was saved from the last time they used the app.
       After the date is changed to a later one than today's, save the txt file and click the play button at the top of
       the Unity Editor's window to start the program. Pause the Unity Editor once again. Open the txt file, and you
       should see that the first line containing the date is updated to today's date and that the following 8 lines are
       only 0's, reflecting the day's total values for each food group.
