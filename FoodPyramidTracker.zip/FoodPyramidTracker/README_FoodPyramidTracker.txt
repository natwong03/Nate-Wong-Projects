Food Pyramid Tracker:
Nate Wong
natwong@chapman.edu
CPSC 236-02
Assignment 5
This is my own work, and I did not cheat on this assignment.

Files:
  a. DataSaver.cs
  b. DataLoader.cs
  c. Pyramid.cs
  d. DataManager.cs

Instructions:
  a. Load unzipped folder into Unity version 2019.4.9f1
  b. Click play button at the top of the window
  c. You can view what constitutes
     a serving for each of the 8 food groups by clicking the "Serving Size Example" button, click the "Back" button
     to return to the home screen
  d. Next, click on any of the 8 food groups to add or take away servings for that group
  e. Click the "Up" or the "Down" button to increase or decrease the value you want to add to the current total for that group.
     The value you will add to the group's total is reflected in the center. Click the "Confirm" button to enter that value.
     Click back to exit the servings adjustment screen if you don't want to edit that food group's total.
  f. The servings count next to the food group button on the main menu shows your total saved servings in comparison
     to what is recommended by the Mayo Clinic for a day's worth of food for individuals with heart disease.
     https://www.mayoclinic.org/healthy-lifestyle/nutrition-and-healthy-eating/in-depth/dash-diet/art-20050989
  g. Click the pause button on the top center of the Unity Editor window to stop the program, doing so will
     automatically save the data you entered to a .txt file
  h. In order to test the daily reset functionality, open the txt file named UserData.txt, found within the Scripts folder,
     which is in the project's Assets folder. On the first line of the file, a date is written in the format of DD/MM/YYYY.
     Change any of those numbers to alter the saved date to a previous date, and put in any desired number in the following
     8 lines (this will help show a change later). This will simulate the user's data that was saved from the last time they used the app.
     After the date is changed to a later one than today's, save the txt file and click the play button at the top of
     the Unity Editor's window to start the program. Pause the Unity Editor once again. Open the txt file, and you
     should see that the first line containing the date is updated to today's date and that the following 8 lines are
     only 0's, reflecting the day's total values for each food group.
