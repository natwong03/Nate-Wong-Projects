﻿/*
Partner #1: Nate Wong
ID# 2344037
natwong @chapman.edu
Partner #2: Grant Ward
ID# 2355746
gward @chapman.edu
CPSC 236-02
Final Assignment, Food Pyramid Tracker
This is my own work, and I did not cheat on this assignment.
*/

using System;
using UnityEngine;
using UnityEngine.UI;

public class DataManager : MonoBehaviour
{
    //this script's purpose is to manage the adjustments of data entered by the user and manage which panel is showing

    public DataLoader loader;

    public GameObject PyramidPanel;
    public GameObject AdjustmentPanel;
    public GameObject InfoPanel;
    public Text CurrentValueText;

    public int CurrentValue;

    public string SelectedGroup = string.Empty;

    private void Start()
    {
        ShowPyramidPanel();
    }

    public void OnIncreaseButtonClick()
    {
        CurrentValue++;
        ReflectCurrentValueToText();
    }

    public void OnDecreaseButtonClick()
    {
        CurrentValue--;
        ReflectCurrentValueToText();
    }

    //adds the curent value the user has selected and the stored value to update the total, total won't go below 0
    public void OnConfirmButtonClick()
    {
        if (SelectedGroup == "Grains")
        {
            int StoredValue = Int32.Parse(loader.UserData[1]);
            int SumOfValues = StoredValue + CurrentValue;

            if(SumOfValues > -1)
            {
                loader.UserData[1] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[1] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "Vegetables")
        {
            int StoredValue = Int32.Parse(loader.UserData[2]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[2] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[2] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "Fruits")
        {
            int StoredValue = Int32.Parse(loader.UserData[3]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[3] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[3] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "Dairy")
        {
            int StoredValue = Int32.Parse(loader.UserData[4]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[4] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[4] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "Meats")
        {
            int StoredValue = Int32.Parse(loader.UserData[5]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[5] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[5] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "Nuts")
        {
            int StoredValue = Int32.Parse(loader.UserData[6]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[6] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[6] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "FatsAndOils")
        {
            int StoredValue = Int32.Parse(loader.UserData[7]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[7] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[7] = SumOfValues.ToString();
            }
        }

        else if (SelectedGroup == "Sweets")
        {
            int StoredValue = Int32.Parse(loader.UserData[8]);
            int SumOfValues = StoredValue + CurrentValue;

            if (SumOfValues > -1)
            {
                loader.UserData[8] = SumOfValues.ToString();
            }
            else
            {
                SumOfValues = 0;
                loader.UserData[8] = SumOfValues.ToString();
            }
        }

        CurrentValue = 0;
        ReflectCurrentValueToText();
        ShowPyramidPanel();
    }

    public void OnBackButtonClick()
    {
        ShowPyramidPanel();
    }

    public void OnServingExamplesButtonClick()
    {
        ShowServingInfoPanel();
    }

    //adjusts the text on the adjustment panel to display the current value the user is about to input
    private void ReflectCurrentValueToText()
    {
        CurrentValueText.text = CurrentValue.ToString();
    }

    private void ShowPyramidPanel()
    {
        PyramidPanel.SetActive(true);
        AdjustmentPanel.SetActive(false);
        InfoPanel.SetActive(false);
    }

    public void ShowAdjustmentPanel()
    {
        AdjustmentPanel.SetActive(true);
        PyramidPanel.SetActive(false);
        InfoPanel.SetActive(false);
    }

    private void ShowServingInfoPanel()
    {
        InfoPanel.SetActive(true);
        PyramidPanel.SetActive(false);
        AdjustmentPanel.SetActive(false);
    }
}
