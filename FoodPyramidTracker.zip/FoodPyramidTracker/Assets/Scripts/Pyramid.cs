﻿/*
Partner #1: Nate Wong
ID# 2344037
natwong @chapman.edu
Partner #2: Grant Ward
ID# 2355746
gward @chapman.edu
CPSC 236-02
Final Assignment, Food Pyramid Tracker
This is my own work, and I did not cheat on this assignment.
*/

using System;
using UnityEngine;
using UnityEngine.UI;

public class Pyramid : MonoBehaviour
{
    //This script's purpose is to manage all of the interactivity with the pyramid and the pyramid's images & text

    public DataManager dataManager;
    public DataLoader loader;

    public Text FoodGroupText;
    public Text GrainsCountText;
    public Text VegetablesCountText;
    public Text FruitsCountText;
    public Text DairyCountText;
    public Text MeatsCountText;
    public Text NutsCountText;
    public Text FatsAndOilsText;
    public Text SweetsText;

    public Button GrainsButton;
    public Button VegetablesButton;
    public Button FruitsButton;
    public Button DairyButton;
    public Button MeatsButton;
    public Button NutsButton;
    public Button FatsButton;
    public Button SweetsButton;

    private void Start()
    {
        UpdatePyramidText();
        UpdatePyramidOpacity();
    }

    //sets the food group the user selected to edit
    public void OnFoodGroupClick(string foodGroupName)
    {
        dataManager.SelectedGroup = foodGroupName;

        FoodGroupText.text = foodGroupName + " Food Group";

        dataManager.ShowAdjustmentPanel();
    }

    //updates the text next to the food group bars to refelct the stored total value of the respective food group
    public void UpdatePyramidText()
    {
        GrainsCountText.text = loader.UserData[1] + " / 7 - Servings";
        VegetablesCountText.text = loader.UserData[2] + " / 5 - Servings";
        FruitsCountText.text = loader.UserData[3] + " / 5 - Servings";
        DairyCountText.text = loader.UserData[4] + " / 3 - Servings";
        MeatsCountText.text = loader.UserData[5] + " / 6 - Servings";
        NutsCountText.text = loader.UserData[6] + " / 5 - Servings";
        FatsAndOilsText.text = loader.UserData[7] + " / 3 - Servings";
        SweetsText.text = loader.UserData[8] + " / 4 or less - Servings";
        
        if (Int32.Parse(loader.UserData[1]) < 0)
        {
            GrainsCountText.text = "0 / 7 - Servings";
        }

        else if (Int32.Parse(loader.UserData[2]) < 0)
        {
            VegetablesCountText.text = "0 / 5 - Servings";
        }

        else if (Int32.Parse(loader.UserData[3]) < 0)
        {
            FruitsCountText.text = "0 / 5 - Servings";
        }

        else if (Int32.Parse(loader.UserData[4]) < 0)
        {
            DairyCountText.text = "0 / 3- Servings";
        }

        else if (Int32.Parse(loader.UserData[5]) < 0)
        {
            MeatsCountText.text = "0 / 6 - Servings";
        }

        else if (Int32.Parse(loader.UserData[6]) < 0)
        {
            NutsCountText.text = "0 / 5 - Servings";
        }

        else if (Int32.Parse(loader.UserData[7]) < 0)
        {
            FatsAndOilsText.text = "0 / 3 - Servings";
        }

        else if (Int32.Parse(loader.UserData[8]) < 0)
        {
            SweetsText.text = "0 / 4 or less - Servings";
        }
    }

    //updates the opacity of the food group button image to reflect progress on the total servings consumed of each respective group
    public void UpdatePyramidOpacity()
    {
        Color baseOpacity = GrainsButton.image.color;
        baseOpacity.a = 0.2f;
        Color fullOpacity = GrainsButton.image.color;
        fullOpacity.a = 1.0f;
        Color oneThird = GrainsButton.image.color;
        oneThird.a = 0.3f;
        Color twoThirds = GrainsButton.image.color;
        twoThirds.a = 0.6f;
        Color oneFourth = GrainsButton.image.color;
        oneFourth.a = 0.35f;
        Color twoFourths = GrainsButton.image.color;
        twoFourths.a = 0.65f;
        Color threeFourths = GrainsButton.image.color;
        threeFourths.a = 0.85f;
        Color oneFifth = GrainsButton.image.color;
        oneFifth.a = 0.3f;
        Color twoFifths = GrainsButton.image.color;
        twoFifths.a = 0.5f;
        Color threeFifths = GrainsButton.image.color;
        threeFifths.a = 0.7f;
        Color fourFifths = GrainsButton.image.color;
        fourFifths.a = 0.8f;
        Color oneSeventh = GrainsButton.image.color;
        oneSeventh.a = 0.25f;
        Color threeSevenths = GrainsButton.image.color;
        threeSevenths.a = 0.4f;

        //handles grains button
        if (Int32.Parse(loader.UserData[1]) == 1)
        {
            GrainsButton.image.color = oneSeventh;
        }

        if (Int32.Parse(loader.UserData[1]) == 2)
        {
            GrainsButton.image.color = oneThird;
        }

        if (Int32.Parse(loader.UserData[1]) == 3)
        {
            GrainsButton.image.color = threeSevenths;
        }

        if (Int32.Parse(loader.UserData[1]) == 4)
        {
            GrainsButton.image.color = twoThirds;
        }

        if (Int32.Parse(loader.UserData[1]) == 5)
        {
            GrainsButton.image.color = threeFifths;
        }

        if (Int32.Parse(loader.UserData[1]) == 6)
        {
            GrainsButton.image.color = threeFourths;
        }

        if (Int32.Parse(loader.UserData[1]) >= 7)
        {
            GrainsButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[1]) == 0)
        {
            GrainsButton.image.color = baseOpacity;
        }

        //handles veggies button
        if (Int32.Parse(loader.UserData[2]) == 1)
        {
            VegetablesButton.image.color = oneFifth;
        }

        if (Int32.Parse(loader.UserData[2]) == 2)
        {
            VegetablesButton.image.color = twoFifths;
        }

        if (Int32.Parse(loader.UserData[2]) == 3)
        {
            VegetablesButton.image.color = threeFifths;
        }

        if (Int32.Parse(loader.UserData[2]) == 4)
        {
            VegetablesButton.image.color = fourFifths;
        }

        if (Int32.Parse(loader.UserData[2]) >= 5)
        {
            VegetablesButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[2]) == 0)
        {
            VegetablesButton.image.color = baseOpacity;
        }

        //handles fruits button
        if (Int32.Parse(loader.UserData[3]) == 1)
        {
            FruitsButton.image.color = oneFifth;
        }

        if (Int32.Parse(loader.UserData[3]) == 2)
        {
            FruitsButton.image.color = twoFifths;
        }

        if (Int32.Parse(loader.UserData[3]) == 3)
        {
            FruitsButton.image.color = threeFifths;
        }

        if (Int32.Parse(loader.UserData[3]) == 4)
        {
            FruitsButton.image.color = fourFifths;
        }

        if (Int32.Parse(loader.UserData[3]) >= 5)
        {
            FruitsButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[3]) == 0)
        {
            FruitsButton.image.color = baseOpacity;
        }

        //handles dairy button
        if (Int32.Parse(loader.UserData[4]) == 1)
        {
            DairyButton.image.color = oneThird;
        }

        if (Int32.Parse(loader.UserData[4]) == 2)
        {
            DairyButton.image.color = twoThirds;
        }

        if (Int32.Parse(loader.UserData[4]) >= 3)
        {
            DairyButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[4]) == 0)
        {
            DairyButton.image.color = baseOpacity;
        }

        //handles meats button
        if (Int32.Parse(loader.UserData[5]) == 1)
        {
            MeatsButton.image.color = oneSeventh;
        }

        if (Int32.Parse(loader.UserData[5]) == 2)
        {
            MeatsButton.image.color = oneThird;
        }

        if (Int32.Parse(loader.UserData[5]) == 3)
        {
            MeatsButton.image.color = twoFifths;
        }

        if (Int32.Parse(loader.UserData[5]) == 4)
        {
            MeatsButton.image.color = twoThirds;
        }

        if (Int32.Parse(loader.UserData[5]) == 5)
        {
            MeatsButton.image.color = threeFourths;
        }

        if (Int32.Parse(loader.UserData[5]) >= 6)
        {
            MeatsButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[5]) == 0)
        {
            MeatsButton.image.color = baseOpacity;
        }

        //handles nuts button
        if (Int32.Parse(loader.UserData[6]) == 1)
        {
            NutsButton.image.color = oneFifth;
        }

        if (Int32.Parse(loader.UserData[6]) == 2)
        {
            NutsButton.image.color = twoFifths;
        }

        if (Int32.Parse(loader.UserData[6]) == 3)
        {
            NutsButton.image.color = threeFifths;
        }

        if (Int32.Parse(loader.UserData[6]) == 4)
        {
            NutsButton.image.color = fourFifths;
        }

        if (Int32.Parse(loader.UserData[6]) >= 5)
        {
            NutsButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[6]) == 0)
        {
            NutsButton.image.color = baseOpacity;
        }

        //handles fats button
        if (Int32.Parse(loader.UserData[7]) == 1)
        {
            FatsButton.image.color = oneThird;
        }

        if (Int32.Parse(loader.UserData[7]) == 2)
        {
            FatsButton.image.color = twoThirds;
        }

        if (Int32.Parse(loader.UserData[7]) >= 3)
        {
            FatsButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[7]) == 0)
        {
            FatsButton.image.color = baseOpacity;
        }

        //handles sweets button
        if (Int32.Parse(loader.UserData[8]) == 1)
        {
            SweetsButton.image.color = oneFourth;
        }

        if (Int32.Parse(loader.UserData[8]) == 2)
        {
            SweetsButton.image.color = twoFourths;
        }

        if (Int32.Parse(loader.UserData[8]) == 3)
        {
            SweetsButton.image.color = threeFourths;
        }

        if (Int32.Parse(loader.UserData[8]) >= 4)
        {
            SweetsButton.image.color = fullOpacity;
        }

        if (Int32.Parse(loader.UserData[8]) == 0)
        {
            SweetsButton.image.color = baseOpacity;
        }
    }
}
