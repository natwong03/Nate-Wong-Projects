﻿/*
Partner #1: Nate Wong
ID# 2344037
natwong @chapman.edu
Partner #2: Grant Ward
ID# 2355746
gward @chapman.edu
CPSC 236-02
Final Assignment, Food Pyramid Tracker
This is my own work, and I did not cheat on this assignment.
*/

using System.IO;
using UnityEngine;

public class DataSaver : MonoBehaviour
{
    public DataLoader loader;

    //This script's purpose is to save data as the app closes
    private void OnApplicationQuit()
    {
        SaveData();
    }

    private void WriteDataToFile()
    {
        StreamWriter writer = new StreamWriter(loader.dataPath);

        for(int i = 0; i < 9; i++)
        {
            writer.WriteLine(loader.UserData[i]);
        }

        writer.Close();
    }

    private void SaveData()
    {
        loader.EnsureFileExists(); /*if for some reason the data file is destroyed
                                    * while the program is running, this will
                                    * create a new data file to save the user's data to
                                    */
        WriteDataToFile();
    }
}
