﻿/*
Partner #1: Nate Wong
ID# 2344037
natwong @chapman.edu
Partner #2: Grant Ward
ID# 2355746
gward @chapman.edu
CPSC 236-02
Final Assignment, Food Pyramid Tracker
This is my own work, and I did not cheat on this assignment.
*/

using System;
using System.IO;
using UnityEngine;

public class DataLoader : MonoBehaviour
{
    //This script's purpose is to load the user's data as the app opens

    public string dataFolderName = "Assets/Data";
    public string dataFileName = "UserData.txt";

    private int readIndex = 0;

    private string[] defaultData = new string[9] { "00/00/0000", "0", "0", "0", "0", "0", "0", "0", "0" };
    public string[] UserData;

    public string dataPath
    {
        get
        {
            return Path.Combine(dataFolderName, dataFileName);
        }
    }

    void Start()
    {
        UserData = Load();

        //check saved date and today's date to see if data needs to be reset or not
        string today = DateTime.Now.ToString("dd/MM/yyyy");

        if(UserData[0] != today)
        {
            UserData[0] = today;

            for(int i = 1; i < 9; i++)
            {
                UserData[i] = "0";
            }
        }
    }

    private void EnsureDirectoryExists()
    {
        if (!Directory.Exists(dataPath))
        {
            Directory.CreateDirectory(dataFolderName);
        }
    }

    public void EnsureFileExists()
    {
        if (!File.Exists(dataPath))
        {
            CreateFile();
        }
    }

    private void CreateFile()
    {
        EnsureDirectoryExists();

        DateTime dateTime = DateTime.UtcNow.Date;
        StreamWriter writer = new StreamWriter(dataPath);
        writer.WriteLine(dateTime.ToString("dd/MM/yyyy"));

        for(int index = 1; index < 9; index++)
        {
            writer.WriteLine(defaultData[index]);
        }

        writer.Close();
    }

    /* Data will include:
     * date
     * grains
     * veggies
     * fruits
     * dairy
     * meats
     * nuts
     * fats/oils
     * sugary sweets
     */

    private string[] ReadDataFromFile()
    {
        string[] data = new string[9];

        StreamReader reader = new StreamReader(dataPath);

        string dataLine = string.Empty;

        while((dataLine = reader.ReadLine()) != null)
        {
            data[readIndex] = dataLine;
            readIndex++;
        }

        reader.Close();

        return data;
    }

    public string[] Load()
    {
        EnsureFileExists();
        return ReadDataFromFile();
    }
}
