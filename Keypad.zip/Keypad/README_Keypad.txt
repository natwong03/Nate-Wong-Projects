Keypad Project:
Nate Wong
natwong@chapman.edu
CPSC 236-02
Assignment 1
This is my own work, and I did not cheat on this assignment.

Files:
  a. Combination.cs
  b. CombinationLoader.cs
  c. Keypad.cs
  d. KeypadButton.cs
  e. KeypadBackground.cs
  f. combination.txt

Instructions:
  a. Load unzipped folder into Unity version 2019.4.9f1
  b. Click the play button
  c. Enter the 4 digit code in the exact sequence of 2-3-1-9, and then click
     the unlock button to unlock the keypad
  d. Click the play button to end the program
  e. Entering the incorrect code will refresh the entered numbers and continue to
     remain locked until correct entry is input
