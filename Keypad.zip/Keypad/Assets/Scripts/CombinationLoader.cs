﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Assignment 2, Keypad
 * This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;
using System.IO; //Added for files

public static class CombinationLoader
{
    private static string combinatinoFolderName = "Assets/Text";
    private static string combinationFileName = "combination.txt";

    private static string combinaitonPath
    {
        get
        {
            return Path.Combine(combinatinoFolderName, combinationFileName);
        }
    }

    private static void EnsureDirectoryExists()
    {
        if (!Directory.Exists(combinaitonPath))
        {
            Directory.CreateDirectory(combinatinoFolderName);
        }
    }

    private static void EnsureFileExists(List<int> defaultCombination) //Checks if combination file already exists, if not, makes new file
    {
        if (!File.Exists(combinaitonPath))
        {
            CreateFile(defaultCombination);
        }
    }

    private static void CreateFile(List<int> defaultCombination) //Creates the combinaiton file
    {
        EnsureDirectoryExists();

        StreamWriter writer = new StreamWriter(combinaitonPath); //takes the pre-defined file path and makes the file
        foreach(int combinationEntry in defaultCombination)
        {
            writer.WriteLine(combinationEntry); //writes each digit to the file on a new line
        }
        writer.Close();
    }

    private static List<int> ReadCombinationFromFile() //reads combination from created file
    {
        List<int> combination = new List<int>();

        StreamReader reader = new StreamReader(combinaitonPath);
        string combinationNumber = string.Empty;

        while((combinationNumber = reader.ReadLine()) != null) //adds each combination digit to the combination variable
        {
            int combinationInteger = int.Parse(combinationNumber);
            combination.Add(combinationInteger);
        }
        reader.Close();

        return combination;
    }

    public static List<int> Load(List<int> defaultCombination) //pulls in combination from combinaiton file
    {
        EnsureFileExists(defaultCombination);
        return ReadCombinationFromFile();
    }
}
