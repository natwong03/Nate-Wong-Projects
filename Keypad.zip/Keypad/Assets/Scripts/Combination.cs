﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Assignment 2, Keypad
 * This is my own work, and I did not cheat on this assignment.
*/

using System.Collections.Generic;

public class Combination
{
    private List<int> combination;
    private List<int> defaultCombination = new List<int> { 2, 3, 1, 9 }; //generates combination

    public Combination()
    {
        combination = CombinationLoader.Load(defaultCombination);
    }

    public int GetCombinationLength()
    {
        return combination.Count;
    }

    public int GetCombinationDigit(int digitNumber)
    {
        if(digitNumber < 0)
        {
            return 0;
        }
        if(digitNumber >= combination.Count)
        {
            return 0;
        }

        return combination[digitNumber];
    }
}
