﻿/* Nate Wong
 * ID# 2344037
 * natwong@chapman.edu
 * CPSC 236-02
 * Assignment 2, Keypad
 * This is my own work, and I did not cheat on this assignment.
*/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Keypad : MonoBehaviour
{
    public List<int> buttonsEntered;

    private Combination combination;
    public KeypadBackground background;

    private void Start()
    {
        combination = new Combination();
        background.ChangeToDefaultColor();
    }

    private void ResetButtonEntries()
    {
        buttonsEntered = new List<int>();
    }

    public void RegisterButtonClick(int buttonValue)
    {
        buttonsEntered.Add(buttonValue);
    }

    public void TryToUnlock()
    {
        //is combination is correct, if so unlock
        if(IsCorrectCombination())
        {
            Unlock();
        }

        else
        {
            //fail to unlock
            FailToUlock();
        }
        //else - failed to unlock

        //resetting button entries
        ResetButtonEntries();
    }

    private void Unlock()
    {
        background.HideUnlockButton();
        background.ChangeToSuccessColor();
    }

    private void FailToUlock()
    {
        background.ChangeToFailColor();
        StartCoroutine(ResetBackgroundColor());
    }

    private IEnumerator ResetBackgroundColor()
    {
        yield return new WaitForSeconds(0.5f);

        background.ChangeToDefaultColor();
    }

    private bool IsCorrectCombination()
    {
        //if buttons have been pressed
        if(NoButtonsClicked())
        {
            return false;
        }
        //did user push the wrong buttons
        if(HaveWrongNumberOfButtonsBeenClicked())
        {
            return false;
        }
        //check combination
        return CheckCombination();
    }

    private bool CheckCombination()
    {
        for(int buttonIndex = 0; buttonIndex < buttonsEntered.Count; buttonIndex++)
        {
            if(IsCorrectButton(buttonIndex) == false)
            {
                return false;
            }
        }

        return true;
    }

    private bool IsCorrectButton(int buttonIndex)
    {
        if (IsWrongEntry(buttonIndex))
        {
            return false;
        }

        return true;
    }

    private bool IsWrongEntry(int buttonIndex)
    {
        if(buttonsEntered[buttonIndex] == combination.GetCombinationDigit(buttonIndex))
        {
            return false;
        }

        return true;
    }

    private bool HaveWrongNumberOfButtonsBeenClicked()
    {
        if(buttonsEntered.Count == combination.GetCombinationLength())
        {
            return false;
        }

        return true;
    }

    private bool NoButtonsClicked()
    {
        if(buttonsEntered.Count == 0)
        {
            return true;
        }

        return false;
    }
}
