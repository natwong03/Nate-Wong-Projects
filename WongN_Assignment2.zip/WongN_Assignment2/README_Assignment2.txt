Nate Wong
Chapman University Student

The first program, Adventure.py, is a choose your own adventure style game that takes user
input and will progress through a story that I wrote. The second program, Pig.py, is a dice
game that is played against the computer.

To use the python scripts, you can load the files into Terminal or Power Shell and the programs
will run.
