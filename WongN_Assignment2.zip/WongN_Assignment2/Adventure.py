#Nate Wong
#2344037
#natwong@chapman.edu
#CPSC 230-01
#Assignment 2

import random #imports the random module so the death chance can be randomly selcted

print('Welcome to the Battle of Yavin Simulator!\n')
print("When prompted for a choice, enter an option given in the previous sentence that was in 'quotes'.")
print("          .                            .       .              .")
print(".  ------------------ .            -)------+====+       .")
print("     .           ---------*-)----====    ,'   ,'   .                 .")
print("              .           .      `.  `.,;___,'       .        .")
print("       .                           `, |____l_\ .          .          . ")
print("                 .   _,....------c==]""______ |,,,,,,.....____ _")
print("    .      .        '-:_____________  |____l_|]'''''''''''       .     .")
print("                                  ,'"",'.   `.      .              .")
print("         . ---------------*-)-----====   `.   `.          .   .")
print("--------------       .            -)-------+====+       .            .\n\n")

room = 1

death_chance = random.randint(1,100) #gives random integer to be used in some choices to trigger the while loop as false

while room != 0: #exit statement
    if room == 1: #beginning
        print("You take off from the hidden Rebel base on Yavin 4, heading to fight what might be your last mission.\n")
        print("You know your orders, 'Protect the Y-Wing bombers in Gold Squadron so they can destroy the Death Star's reactor.'\n")
        print("You make the jump to hyperspace with your squadron and soon drop out in front of the massive Death Star.\n")
        print("Quick! Tie Fighters are approaching us quickly! Choose to either rush and 'take out' the fighters or stay and 'protect' Gold Squadron.\n")
        choice = input("What do you choose squad leader? ")
        choice = choice.lower() #used .lower() so capitalization wouldn't cause the else condition to trigger even if spelling is right
        print('----------------')
        if choice == 'take out':
            if death_chance >= 55: #first chance of 'death'
                print("\nGold Squadron was unprotected and wiped out. Mission Failed.\nRestart and try again\n.")
                room = 0
            else:
                print("\nThat was a close one, no damage to Gold Squadron's bombers.\n")
                room = 2
                death_chance = random.randint(1,100) #makes a new random int. for the next death chance
        elif choice == 'protect':
            print("\nYou were able to easily take out the advancing TIEs with the help of the Y-Wing gunners.\n")
            room = 2
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 2: #trench choice
        print("You approach the surface of the Death Star and can fly through the 'left' trench or the 'right' trench.\n")
        choice = input("Which trench do you choose? ")
        choice = choice.lower()
        print('----------------')
        if choice == 'left':
            room = 3
        elif choice == 'right':
            print("\nThe ion canons have started to fire at you and your squad!\n")
            if death_chance >= 80:
                print("BOOM!! Your stabilizer is destroyed and you spiral into the trench wall!\n\nRestart and try again.\n")
                room = 0
            else:
                print("You managed to take out the canons with minimal losses.\n")
                room = 4
                death_chance = random.randint(1,100)
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 3: #dead end with backtracking
        print("\nThe left trench looks like it's going to the wrong location, better turn around and go right.\n")
        choice = input("Write 'turn around' to go back. ")
        choice = choice.lower()
        if choice == 'turn around':
            print()
            room = 2
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 4: #first big splitting point for adventure
        print("\nYou see Darth Vader's TIE Advanced chasing Luke Skywalker's X-Wing in the distance.")
        choice = input("Do you 'help' Luke or 'no'? ")
        choice = choice.lower()
        print('----------------')
        if choice == 'help': #ends adventure sooner
            print("\nYou line up the shot and you hit Vader's ship causing him to retreat! Luke thanks you and he makes a run for the reactor.\n")
            print("Luke fires a proton torpedo and he hits his mark, causing the Death Star to explode! Better get out of there fast!\n")
            room = 5
        elif choice == 'no': #lets the user go further
            print("\nSorry Luke!\n")
            room = 6
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 5: #first possible main ending
        print("You and the rest of your squadron safely made it back to Yavin 4 where you're welcomed and congradulated by the other Rebels.\n")
        print("Congratulations! You completed your mission and helped save the galaxy from the Empire!\n")
        print('----------------\n')
        room = 0

    elif room == 6: #user will choose to stay in space or go into the Death Star
        print("You and Gold Squadron approach the reactor vent, when suddenly more TIE Fighters attack and destroy all of the Y-Wing bombers.\n")
        print("It's up to you now to complete the mission.\n")
        choice = input("Do you choose to use proton 'torpedoes' from your X-Wing to destroy the reactor or go 'inside' the Death Star to destroy the reactor? ")
        choice = choice.lower()
        print('----------------')
        if choice == 'torpedoes':
            print("\nOk...here goes nothing.\n")
            room = 7
        elif choice == 'inside':
            print("\nThis will be the most dangerous part of your mission. Good Luck.")
            room = 8
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 7:
        print("You aim down your sights for the reactor vent, a very small opening.")
        choice = input("The target is within range! 'Fire' when you're ready!")
        choice = choice.lower()
        print('----------------')
        hit_chance = random.randint(1,100) #gives a random int. which will trigger or not trigger the ending in room 5
        if choice == 'Fire' or 'fire':
            if hit_chance >= 55: #45% chance to 'hit' the target and trigger ending. if not triggered, the else condition will start the room over again to have the user 'fire' and a new random int. is created
                print("You did it!! The reactor was hit and a chain explosion has triggered. You and the remaining Rebels quickly jump to hyperspace and head back to base.\n")
                room = 5
            else:
                print("Try your shot again!\n")
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 8: #hangar room
        print("\nYou land your ship in a nearby empty hangar and make your way to the reactor as fast as you can go.\n")
        print("As you enter the hallway Stormtroopers appear from nowhere and shoot at you! You take cover and fire back!\n")
        if death_chance >= 70:
            print("There's too many!! Your little amount of cover isn't enough to protect you as the Stormtroopers overwhlem you with laser fire.\n")
            print("You weren't able to destroy the reactor before you died.\n")
            print("\nRestart and try again.\n")
            room = 0
        else:
            print("You got the last one.\n")
            choice = input("The hallway is clear, 'move up' to the reactor! ")
            choice = choice.lower()
            print('----------------')
            if choice == 'move up':
                death_chance = random.randint(1,100)
                room = 9
            else:
                print()
                print(choice, "isn't an option, try again.")

    elif room == 9: #reactor room where user get's to choose how they want to destroy it
        print("\nYou run up to the massive reactor core and have two options to destroy it, to either use a 'thermal detonator' or 'hack' into it.")
        choice = input("Which way will you choose? ")
        choice = choice.lower()
        print('----------------')
        if choice == 'thermal detonator':
            room = 10
        elif choice == 'hack':
            room = 12
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 10:
        print("\nYou won't be able to make it out alive this way, are you sure you want to do this?\n")
        choice = input("Choose 'yes' or 'no'. ")
        choice = choice.lower()
        print('----------------')
        if choice == 'yes':
            print("Ok...your sacrifice for the galaxy won't be forgotten.\n")
            room = 11
        elif choice == 'no':
            room = 9
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 11: #second possible main ending
        print("You plant the charges around the base of the reactor, setting each charge to blow when you tigger them.\n")
        choice = input("The last charge is placed, 'detonate' when ready. ")
        choice = choice.lower()
        print('----------------')
        if choice == 'detonate':
            print("BOOM\n")
            room = 0
        else:
            print()
            print(choice, "isn't an option, try again.")

    elif room == 12: #third possible main ending
        print("You hack into the system and bypass the main security until you come across a simple security question.\n")
        choice = input('To make sure you are the former apprentice to Obi-Wan, what is the proper response to the phrase "Hello there"? Type "back" if unsure. ')
        choice = choice.lower()
        print('----------------')
        if choice == 'general kenobi': #star wars joke from episode 3 when obi-wan fights general grevious
            print("\nCorrect.")
            print("\nYou did it!! A countdown timer begins, giving you just enough time to get back to your X-Wing and get out!\n")
            print("You make it off of the Death Star just before it explodes and you jump to hyperspace! You saved the galaxy!!\n")
            room = 0
        elif choice == 'back': #if the user doesn't get the joke they can go back and choose the detonator ending
            room = 9
        else:
            print()
            print(choice, "incorrect, try again.")

print("Simulation complete! Go again to try to get a different ending.") #message for the end of the adventure game
