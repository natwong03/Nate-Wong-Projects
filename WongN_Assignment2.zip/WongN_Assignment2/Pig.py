#Nate Wong
#2344037
#natwong@chapman.edu
#CPSC 230-01
#Assignment 2

import random #imports the random module so the dice can be randomly rolled

print("\nWelcome to Pig!")
print("Here are the quick rules:\n")
print("Pig is a simple two-player dice game in which the first player to reach 100 or more points wins.\n")
print("Players take turns. On each turn a player rolls a six-sided die. After each roll:\n")
print("a) If the player rolls a 1 then the player gets no new points and it becomes the other player’s turn.")
print("b) If the player rolls 2-6 then they can either roll again or hold. If the player holds the sum of all rolls is added to his/her score and the turn passes to the other player.")
print("c) The computer will automatically hold once it's turn score is 20 or greater.\n")
print("When prompted, enter 'r' to roll and 'h' to hold.\n")

player = 'human' #establishes who's turn it is, starts with the human first

dice_value = random.randint(1,6) #acts as real life dice and randomly chooses a number between 1 and 6 inclusive

human_total = 0
cp_total = 0

human_turnScore = 0
cp_turnScore = 0

while human_total < 100 and cp_total < 100:
    print("-----------------------------")
    print("Player:", player)
    print()
    print("Your score is: {}, the computer's score is: {}.\n".format(human_total, cp_total))
    while player == 'human': #holds all the instructions for when it's the human's turn

        choice = input("Choose to roll 'r' or hold 'h'. ") #gives player option to roll or hold
        choice = choice.lower()
        if choice == 'r':
            if dice_value > 1: #adds the dice value to the turn score and rerandomizes the dice value
                human_turnScore += dice_value
                print("You rolled a {}. Turn score: {}".format(dice_value, human_turnScore))
                print()
                dice_value = random.randint(1,6)
            elif dice_value == 1: #ends player's turn if a 1 is rolled
                print("Bad luck! You rolled a 1.\n")
                human_turnScore = 0
                player = 'cp'

        elif choice == 'h':
            human_total += human_turnScore
            print("You held {} points. Your total score is {}.".format(human_turnScore, human_total))
            if human_total >= 100: #used a break statement so if the human scores 100+ then the computer doesn't go since the human already won
                break
            human_turnScore = 0
            dice_value = random.randint(1,6) #makes a new dice value
            player = 'cp'

        else:
            print()
            print(choice, "isn't a choice, try again.")

    print("-----------------------------")
    print("Player:", player)
    print()
    print("Your score is: {}, the computer's score is: {}.\n".format(human_total, cp_total))
    while player == 'cp': #holds all of the instrucitons for when it's the computer's turn
        if cp_turnScore >= 20: #adds total score and turn score when computer gets 20+ for the turn and ends computer's turn
            cp_total += cp_turnScore
            print("The computer had a turn score of {}. Computer total score: {}".format(cp_turnScore, cp_total))
            cp_turnScore = 0
            player = 'human'

        elif cp_turnScore < 20: #makes computer roll if under 20 points in the turn still
            if dice_value > 1:
                cp_turnScore += dice_value
                print("The computer rolled a {}. Turn score: {}".format(dice_value, cp_turnScore))
                print()
                dice_value = random.randint(1,6)

            elif dice_value == 1: #ends computer's turn if it rolls a 1
                print("The computer rolled a 1!")
                cp_turnScore = 0
                dice_value = random.randint(1,6)
                player = 'human'

if human_total > cp_total: #displays message if human won
    print("You win!!")

elif cp_total > human_total: #displays message if computer won
    print("Your score is: {}, the computer's score is: {}.\n".format(human_total, cp_total))
    print("\nThe computer won. Try again!")

print("Game finished.")
