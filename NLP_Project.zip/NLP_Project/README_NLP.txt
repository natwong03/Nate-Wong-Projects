Natural Language Processor:
Nate Wong
natwong@chapman.edu
CPSC 230
Assignment 4
This is my own work, and I did not cheat on this assignment.

Files:
  a. NLP.py
  b. hp.txt

Instructions:
  a. Ensure Python3 is installed on your computer
  b. Open Terminal or PowerShell and navigate to the NLP_Project folder
  c. Run the NLP.py file
  d. Check the new counts.txt file in the NLP_Project folder for the results
