Nate Wong
Chapman University Student

The first program, Complement.py, is designed to return the complement DNA sequence
that the user inputs. The second program, Stats.py, will take a collection of integers
from the user's input and return the calculated mean, standard deviation, and variance of the
given values.

To use the python scripts, you can load the files into Terminal or Power Shell and the programs
will run.
