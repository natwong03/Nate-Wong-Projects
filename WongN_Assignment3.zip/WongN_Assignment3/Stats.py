# Nate Wong
# 2344037
# natwong@chapman.edu
# CPSC 230-01
# Assignment 3

import math #brings in math module for a later calculation of the standard deviation

def sorted_list(mod_list): #this funciton sorts the list that the user creates
    mod_list.sort() #utilizes the .sort() list method to organize the user's list
    return mod_list

def compute_mean(user_list): #this function calculates the mean value of the list that the user enters
    list_mean = sum(user_list) / len(user_list)
    return list_mean

def compute_variance(user_list): #this function calculates the variance of the list that the user enters
    sum_var_pt1 = 0
    for n in user_int_list:
        sum_var_pt1 += ((n - compute_mean(user_list)) ** 2) #calculates the numerator of the variance
    variance = sum_var_pt1 / len(user_list) #completes the variance calculation
    return variance

def compute_standard_dev(user_var): #this function calculates the standard deviation of the list that the user enters
    std_dev = math.sqrt(user_var) #the math.squrt() module is used here so we can take the square root of the variance
    return std_dev

#main
print("\nThis program will ask you for positive integers and will give you the mean and standard deviation once you are done adding your values.\n")
print("Enter a negative integer to stop.\n")

loop_control = 1 #establishes controlling variable of the following while loop

user_int_list = [] #establishes the list that will store the user's positive integers

while loop_control != 0: #this allows the program to continually prompt the user for values until they enter a negative number
    user_input = int(input("Enter your positive integer: "))
    if user_input < 0: #this condition will trigger the while loop to stop asking for more integers once the user enters a negative value
        loop_control = 0
    else: #adds the user's most recent input to the integer list
        user_int_list.append(user_input)
        print("Your list:", user_int_list)

print()
print("Data:", sorted_list(user_int_list)) #inserts the list created by the user into the sorted list function
print()
print("The mean of your data is:", compute_mean(user_int_list)) #inserts the list created by the user into the compute mean function
print()
list_varience = compute_variance(user_int_list) #inserts the list created by the user into the compute variance function, needed for the following line
print("The standard deviation of your data is:", compute_standard_dev(list_varience)) #inserts the varience of the list into the compute standard deviation function

print("\nDone.")
