# Nate Wong
# 2344037
# natwong@chapman.edu
# CPSC 230-01
# Assignment 1

purchase_price = float(input('Enter the purchase price of the item: '))

if purchase_price < 0: #checks for a positive purchase price
    print('Please enter a positive purchase price.')

elif purchase_price == 0: #checks for a purchase price of $0
    print("It's free! No need to calculate tax to get a total price!")

elif purchase_price > 0: #checks for a positive purchase price
    tax_rate = float(input('Enter sales tax rate: '))

    if tax_rate < 0: #checks for a positive tax rate
        print("Please enter a positive tax rate.")

    elif tax_rate == 0: #checks for a tax rate equal to 0%
        print('Your total price is:')
        print('$''{:.2f}'.format(purchase_price))

    elif tax_rate > 0: #checks for a positive tax rate
        tax_rate = tax_rate / 100

        total_price = purchase_price * (1 + tax_rate) #computes total price

        print('Your total price is:')
        print('$''{:.2f}'.format(total_price))
