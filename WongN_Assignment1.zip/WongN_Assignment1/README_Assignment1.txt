Nate Wong
Chapman University Student

The program Con_Sum.py will take a user's integer that they input, and return the
consecutive sum from 1 up to the input number. Essentially a factorial calculator.
The second program, Quadratic.py, takes in three integers from user input and will
calculate the quadratic formula using them. The third program, Seconds.py, takes
an integer between 1 and 86,000 (the # of seconds in a day), and will return how
many hours, minutes, and seconds that is in total. Lastly, the program TotalPrice.py
takes the purchase price of an item and the sales tax rate, and then calculates
the total price including tax.

To use the python scripts, you can load the files into Terminal or Power Shell and the programs
will run.
