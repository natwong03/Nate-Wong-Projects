# Nate Wong
# 2344037
# natwong@chapman.edu
# CPSC 230-01
# Assignment 1

x = int(input('Enter integer: '))
sum = 0

for i in range (1, x + 1): #loops until the end of the range is reached, which is also the same number the user input
    sum += i #adds the next value of i to the current value of sum

print('The consecutive sum from 1 to {} is:'.format(x), sum)
