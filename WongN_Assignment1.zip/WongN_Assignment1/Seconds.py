# Nate Wong
# 2344037
# natwong@chapman.edu
# CPSC 230-01
# Assignment 1

user_sec = int(input('Enter a number between 1 and 86,400: '))

hours = user_sec // 3600 #claculates the number of hours
minutes = int(((user_sec / 60) % 60)) #calculates the number of minutes
seconds = user_sec % 60 #calculates the number of seconds

print(user_sec, 'seconds is', hours, 'hours,', minutes, 'minutes,', 'and', seconds, 'seconds.')
