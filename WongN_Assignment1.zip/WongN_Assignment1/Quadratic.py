# Nate Wong
# 2344037
# natwong@chapman.edu
# CPSC 230-01
# Assignment 1

import math

a = float(input('Enter the value for A: '))
b = float(input('Enter the value for B: '))
c = float(input('Enter the value for C: '))

while (b ** 2 - 4 * a * c) < 0: #prompts user to give values which equate to a positive discriminant
    print('Please enter new vlaues that give a non-negative discriminant.')
    a = float(input('Re-enter the value for A: '))
    b = float(input('Re-enter the value for B: '))
    c = float(input('Re-enter the value for C: '))

while (b ** 2 - 4 * a * c) == 0: #gives the single result of x for a discriminant equal to 0
    x = (-b + math.sqrt(b ** 2 - 4 * a * c)) / (2 * a) #doesn't matter if -b is added or subtracted since the...
    #x axis is only touched once when the discriminant is equal to 0

    print('The quadratic formula says that the solution for x is:')
    print('x =', x)
    break #used to exit loop

while (b ** 2 - 4 * a * c) > 0: #gives the two results of x for a positive discriminant
    x1 = (-b + math.sqrt(b ** 2 - 4 * a * c)) / (2 * a)
    x2 = (-b - math.sqrt(b ** 2 - 4 * a * c)) / (2 * a)

    print('The quadratic formula says that the solutions for x are:')
    print('x =', x2, 'and', x1)
    break #used to exit loop
